// frontend/srcs/js/PongGame/gameSettings.js

export const gameSettings = {

    /*************** Paramètres communs à 2D et 3D **************/
    
    // Score
    winningScore: 5,             // Score à atteindre pour gagner
    
    // Power-ups
    powerUpEffectDuration: 7000,  // 7 sec de durée des power-ups

    // Rally
    setRally: 0,                 // Désactive ou active le mode rallye

    /***************** Paramètres spécifiques au 2D *****************/

    // Dimensions du canvas
    canvasWidthFactor: 0.9,
    aspectRatio: 16 / 9, 

    // Paddle 
    resetPaddlePosition: 0,       // Réinitialiser la position du paddle après un point
    paddleWidthFactor: 0.035,     // Largeur du paddle en fonction du canvas
    paddleHeightFactor: 0.25,     // Hauteur du paddle

    // Ball
    ballSizeFactor: 0.015,        // Taille de la balle

    // Vitesse du jeu
    paddleSpeedFactor: 5,         // Facteur de vitesse du paddle
    ballSpeedX: 5,                // Vitesse en X de la balle
    ballSpeedY: 5,                // Vitesse en Y de la balle

    // IA
    setPowerUps: 0,               // Désactive ou active les power-ups
    difficultyLevel: "novice",    // Niveau de difficulté de l'IA
    errorMargin: 0,               // Marge d'erreur pour l'IA
    aiSpeedFactor: 5,             // Facteur de vitesse pour l'IA

    // Bordures
    borderFactor: 0.025,          // Facteur pour la taille des bordures
    minBorderSize: 1,             // Taille minimale des bordures
    borderColor: '#a16935',       // Couleur des bordures

    /***************** Paramètres spécifiques au 3D *****************/

    // Limites de mouvement en 3D
    ballMovementLimitX: 0,        // Limite de mouvement de la balle en X (3D)
    ballMovementLimitZ: 0,        // Limite de mouvement de la balle en Z (3D)
    paddleMovementLimit: 0,       // Limite de mouvement du paddle en 3D

};
