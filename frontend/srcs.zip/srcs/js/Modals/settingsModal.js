// frontend/srcs/js/Modals/settingsModal.js

// Importer les fonctions spécifiques à chaque mode de jeu
import { saveGameSettings, loadSettingsOnPageLoad, initializeGameSettings } from './gameSettingsModal2D.js';
import { loadSettingsOnPageLoad3D, initializeGameSettings3D, saveGameSettings3D } from './gameSettingsModal3D.js';
import { initializeWinMsg } from './winMsgModal.js';
import { resetGame } from './startGameModal.js';

// Initialisation pour le mode 2D
export function initializeButton2D() {
    loadSettingsOnPageLoad();  
    initializeGameSettings();    // Spécifique au 2D
    saveGameSettings();          // Sauvegarder les paramètres du 2D
    initializeWinMsg();          // Initialiser le message de victoire
    resetGame();                 // Réinitialiser le jeu
}

// Initialisation pour le mode 3D
export function initializeButton3D() {
    loadSettingsOnPageLoad3D();  // Charger les paramètres spécifiques au 3D
    initializeGameSettings3D();  // Spécifique au 3D
    saveGameSettings3D();        // Sauvegarder les paramètres du 3D
    initializeWinMsg();          // Initialiser le message de victoire
    resetGame();                 // Réinitialiser le jeu
}
